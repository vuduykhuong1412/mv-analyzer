// GifAnimation.cpp : implementation file
//

#include "stdafx.h"
#include "YUVanalyzer.h"
#include "YUVplayback.h"
#include "YUVAnalyzerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "Convert.h"

/////////////////////////////////////////////////////////////////////////////
// CYUVPlayback

CYUVPlayback::CYUVPlayback()
	:CStatic()
{
	bHaveFile = FALSE;
	m_pFile = NULL;
	m_pFile = new CFile();

	iTotalFrameNumber = 0;
	iCurrFrameNumber = 0;
	iWidth = 0;
	iHeight = 0;

	bColorful = YUV;
	bShowMV = FALSE;
	bShowGrid = FALSE;
	bShowSign = FALSE;

	Y = NULL;
	Cb = NULL;
	Cr = NULL;
	RGBbuf = NULL;
	QMB = NULL;

	CenterX = CenterY = 0;
	ZoomFactor = 1.0;
	TotalQMB = 0;
	QMB_bx = -1;
	QMB_by = -1;

	BmpInfo=(BITMAPINFO*)new char [sizeof(BITMAPINFO)+sizeof(RGBQUAD)*256];
}

CYUVPlayback::~CYUVPlayback()
{
	free(Y);
	free(Cb);
	free(Cr);
	free(RGBbuf);
	free(QMB);

	delete BmpInfo;
	delete m_pFile;
}

BEGIN_MESSAGE_MAP(CYUVPlayback, CStatic)
	//{{AFX_MSG_MAP(CYUVPlayback)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CYUVPlayback message handlers

void CYUVPlayback::OnPaint() 
{
	if ( bHaveFile == FALSE )
	{
		CStatic::OnPaint();
		return;
	}

	CPaintDC dc(this); // device context for painting
	
	switch (bColorful) {
	case YUV:
		ShowColorImage(&dc);
		break;
	case YY:
		ShowYImage(&dc);
		break;
	case LG:
		ShowLGImage(&dc);
		break;
	case ND:
		ShowNDImage(&dc);
		break;
	default:
		break;
	}
}

void CYUVPlayback::DoDataExchange(CDataExchange* pDX)
{
	CStatic::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CYUVPlayback)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CYUVReference public interface
// Constructor/Destructor: CYUVReference() , ~CYUVReference()
// Mode Setting:	SetColorful() , SetShowMV() , SetShowGrid() , SetShowSign()
// Zoom In/Out:		ZoomIn() , ZoomOut()
// Drag Related:	DragStart() , Drag()
// QMB Finding:		PrevQMB() , NextQMB()
// Unknown:			SetPathName() , SetYUVSize() // should be deleted
// Playback:		ReStart() , GoToFrame()
//

// set the colorful display
void CYUVPlayback::SetColorful(int colorful)
{
	bColorful = colorful;
}

// set the gray display
void CYUVPlayback::SetShowMV(BOOL bMV)
{
	bShowMV = bMV;
}

// set the light gray display
void CYUVPlayback::SetShowGrid(BOOL grid)
{
	bShowGrid = grid;
}

// set no display
void CYUVPlayback::SetShowSign(BOOL sign)
{
	bShowSign = sign;
}

// zoom in the picture without change the center position
void CYUVPlayback::ZoomIn()
{
	GetClientRectSize();
	double maxZF = iWidth * 4 / rw;

	ZoomFactor *= 1.1;
	if (ZoomFactor == maxZF) return;
	if (ZoomFactor > maxZF) { ZoomFactor = maxZF; }

	ReCalulateShowParam();
	
	Invalidate(FALSE);
}

// zoom out the picture without change the center position
void CYUVPlayback::ZoomOut()
{
	ZoomFactor /= 1.1;
	if (ZoomFactor == 1) return;
	if (ZoomFactor < 1) { ZoomFactor = 1; }

	ReCalulateShowParam();

	Invalidate(FALSE);
}

// record the drag start position for Drag()
void CYUVPlayback::DragStart()
{
	DragStart_x_left = x_left;
	DragStart_x_right = x_right;
	DragStart_y_top = y_top;
	DragStart_y_bottom = y_bottom;
	DragStart_CenterX = CenterX;
	DragStart_CenterY = CenterY;
}

// drag the yuv picture move in real time
void CYUVPlayback::Drag(int x, int y)
{
	GetClientRectSize();

	int movex, movey;
	BOOL needRefresh = FALSE;

	// calculate the pro rate movement in the original YUV picture
	movex = (DragStart_x_right - DragStart_x_left) * x / (rw-2*edge_x);
	movey = (DragStart_y_bottom- DragStart_y_top) * y / (rh-2*edge_y);

	if (DragStart_x_left-movex>=0 && DragStart_x_right-movex<iWidth) {
		x_left = DragStart_x_left - movex;
		x_right = DragStart_x_right - movex;
		CenterX = DragStart_CenterX - movex;
		needRefresh = TRUE;
	}
	if (DragStart_y_top-movey>=0 && DragStart_y_bottom-movey<iHeight) {
		y_top = DragStart_y_top - movey;
		y_bottom = DragStart_y_bottom - movey;
		CenterY = DragStart_CenterY - movey;
		needRefresh = TRUE;
	}

	if (needRefresh) {
		Invalidate(FALSE);
	}
}

void CYUVPlayback::PrevQMB()
{
	if (TotalQMB == 0) return;

	int temp_bx = QMB_bx;
	int temp_by = QMB_by;
	MBData *temp_mbd = QMB + temp_by*iWidth/MB_SIZE + temp_bx;
	for (int by=0; by<iHeight/MB_SIZE; by++) {
		for (int bx=0; bx<iWidth/MB_SIZE; bx++) {
			MBData* mbd = QMB + by*iWidth/MB_SIZE + bx;
			if (CheckMBSign(mbd) == QUE) {
				if (bx==QMB_bx && by==QMB_by) {
					QMB_bx = temp_bx;
					QMB_by = temp_by;
					pDlg->m_FocusArea.SetFocusArea(temp_mbd, QMB_bx, QMB_by);
					return;
				}
				temp_bx = bx;
				temp_by = by;
				temp_mbd = mbd;
			}
		}
	}
}

void CYUVPlayback::NextQMB()
{
	if (TotalQMB == 0) return;

	BOOL foundCurr = FALSE;
	for (int by=0; by<iHeight/MB_SIZE; by++) {
		for (int bx=0; bx<iWidth/MB_SIZE; bx++) {
			MBData* mbd = QMB + by*iWidth/MB_SIZE + bx;
			if (CheckMBSign(mbd) == QUE) {
				if (foundCurr == TRUE) {
					QMB_bx = bx;
					QMB_by = by;
					pDlg->m_FocusArea.SetFocusArea(mbd, bx, by);
					return;
				}
				if (bx==QMB_bx && by==QMB_by) foundCurr = TRUE;
			}
		}
	}
}

// double click to select the questionable macroblock by hand
void CYUVPlayback::SelectMB(int x, int y) 
{
	if (x<edge_x || x>=rw-edge_x || y<edge_y || y>=rh-edge_y)
		return;

	int bx = (int)toPictureX(x) / MB_SIZE;
	int by = (int)toPictureY(y) / MB_SIZE;
	MBData* mbd = QMB + by*iWidth/MB_SIZE + bx;
	pDlg->m_FocusArea.SetFocusArea(mbd, bx, by);
}

// need to modify, use main window reference is ok.
void CYUVPlayback::SetPathName(char *pathname)
{
	if (bHaveFile) {
		m_pFile->Close();
	}

	sprintf( sPathName, "%s", pathname );

	bHaveFile = TRUE;
}

// need to modify, use main window reference is ok.
void CYUVPlayback::SetYUVSize(int width, int height)
{
	iWidth = width;
	iHeight = height;
	CenterX = width >> 1;
	CenterY = height >> 1;

	if (Y!=NULL) free(Y);
	if (Cb!=NULL) free(Cb);
	if (Cr!=NULL) free(Cr);
	if (RGBbuf!=NULL) free(RGBbuf);
	if (QMB!=NULL) free(QMB);

	if ( (Y =(unsigned char *)malloc(iWidth*iHeight)) == NULL ) 
	{
		//AfxMessageBox("Couldn't allocate memory for RGBbuf\n");
		return;
	}
	if ( (Cb=(unsigned char *)malloc(iWidth*iHeight/4)) == NULL ) 
	{
		//AfxMessageBox("Couldn't allocate memory for RGBbuf\n");
		return;
	}
	if ( (Cr=(unsigned char *)malloc(iWidth*iHeight/4) ) == NULL ) 
	{
		//AfxMessageBox("Couldn't allocate memory for RGBbuf\n");
		return;
	}
	if ( (RGBbuf=(unsigned char *)malloc(iWidth*iHeight*3)) == NULL ) 
	{
		//AfxMessageBox("Couldn't allocate memory for RGBbuf\n");
		return;
	}
	if ( (QMB=(MBData *)malloc(iWidth*iHeight*sizeof(MBData))) == NULL ) 
	{
		//AfxMessageBox("Couldn't allocate memory for RGBbuf\n");
		return;
	}
}

// ReStart when open the new YUV file, change the yuv setting, etc.
// It will re-calculate some important member variables, re-read
// the YUV file.
int CYUVPlayback::ReStart()
{
	GetClientRectSize();
	iCurrFrameNumber = 0;

	if ( bHaveFile == FALSE )
		return 0;

	if(!m_pFile->Open(sPathName, CFile::modeRead | CFile::typeBinary | CFile::shareDenyNone )) 
	{
		//AfxMessageBox("Can't open input file");
		return 0;
	}
	iTotalFrameNumber = m_pFile->GetLength() / (iWidth*iHeight*3/2);
	GetYUVData();

	ReCalulateShowParam();
	CenterX = (x_left + x_right) / 2;
	CenterY = (y_top + y_bottom) / 2;
	FindQuestionableMV();

	Invalidate(FALSE);

	return iTotalFrameNumber;
}

// Get the YUV data of frame "number", and display it.
void CYUVPlayback::GoToFrame(int number)
{
	if ( bHaveFile == FALSE )
		return;

	iCurrFrameNumber = number;
	if (iCurrFrameNumber >= iTotalFrameNumber-1 || iCurrFrameNumber < 0) {
		iCurrFrameNumber = -1;
	}

	if (iCurrFrameNumber >=0 && iCurrFrameNumber <= iTotalFrameNumber-1 ) {
		m_pFile->Seek(iCurrFrameNumber*iWidth*iHeight*3/2, CFile::begin);
		// Read the Y Cb Cr data
		GetYUVData();
		FindQuestionableMV();
		Invalidate(FALSE);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CYUVReference private functions
// YUV data reader:		GetYUVData() , GetMVData()
// Picture display:		ShowColorImage() , ShowYImage() , ShowLGImage() , ShowNDImage()
// Information display:	ShowGrids() , DrawRectangle() , ShowMVs() , DrawMV() , ShowSigns() , DrawBlockSign()
// Coordinates translate:	toWindowX() , toWindowY() , toPictureX() , toPictureY()
// Parameters:			ReCalulateShowParam()
// Window related:		GetClientRectSize() , DrawBackground()
// QMB related:			FindQuestionableMV()
//

// requrire the file point is valid and correct
void CYUVPlayback::GetYUVData()
{
	if ( m_pFile->Read(Y, iWidth*iHeight) != (unsigned int)(iWidth*iHeight) )
	{
		//AfxMessageBox("Get to end of file");
		return;
	}
	if ( m_pFile->Read(Cb, iWidth*iHeight/4) != (unsigned int)(iWidth*iHeight/4) )
	{
		//AfxMessageBox("Get to end of file");
		return;
	}
	if ( m_pFile->Read(Cr, iWidth*iHeight/4) != (unsigned int)(iWidth*iHeight/4) )
	{
		//AfxMessageBox("Get to end of file");
		return;
	}
}

// get motion vectors information from the *.mv file
void CYUVPlayback::GetMVData()
{
}

// display the colorful image
void CYUVPlayback::ShowColorImage(CDC *pDC)
{
	DrawBackground(pDC);
	if (iCurrFrameNumber < 0)
		return;

	int BPP = 24;
	BmpInfo->bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
	BmpInfo->bmiHeader.biWidth=iWidth;
	BmpInfo->bmiHeader.biHeight=iHeight;			// negative means up-to-bottom 
	BmpInfo->bmiHeader.biPlanes=1;
	BmpInfo->bmiHeader.biBitCount=(BPP<8?8:BPP);	// Our raster is byte-aligned
	BmpInfo->bmiHeader.biCompression=BI_RGB;
	BmpInfo->bmiHeader.biSizeImage=0;
	BmpInfo->bmiHeader.biXPelsPerMeter=11811;
	BmpInfo->bmiHeader.biYPelsPerMeter=11811;
	BmpInfo->bmiHeader.biClrUsed=0;
	BmpInfo->bmiHeader.biClrImportant=0;

	// convert the YUV pictuer(Y,Cb,Cr) into RGB picture(RGBbuf)
	ColorSpaceConversions conv;
	conv.YV12_to_RGB24(Y, Cb, Cr, RGBbuf, iWidth, iHeight);

	// draw the picture
	pDC->SetStretchBltMode(STRETCH_DELETESCANS);
	StretchDIBits(pDC->m_hDC,
					edge_x, edge_y, rw-2*edge_x, rh-2*edge_y,
					x_left, iHeight-y_bottom, x_right - x_left, y_bottom - y_top,
					RGBbuf, BmpInfo, DIB_RGB_COLORS,SRCCOPY);

	ShowGrids(pDC); ShowSigns(pDC); ShowMVs(pDC);
}

// display the gray image
void CYUVPlayback::ShowYImage(CDC *pDC)
{
	DrawBackground(pDC);
	if (iCurrFrameNumber < 0)
		return;

	int BPP = 8;
	BmpInfo->bmiHeader.biSize=sizeof (BITMAPINFOHEADER);
	BmpInfo->bmiHeader.biWidth=iWidth;
	BmpInfo->bmiHeader.biHeight=iHeight;			// negative means up-to-bottom 
	BmpInfo->bmiHeader.biPlanes=1;
	BmpInfo->bmiHeader.biBitCount=(BPP<8?8:BPP);	// Our raster is byte-aligned
	BmpInfo->bmiHeader.biCompression=BI_RGB;
	BmpInfo->bmiHeader.biSizeImage=0;
	BmpInfo->bmiHeader.biXPelsPerMeter=11811;
	BmpInfo->bmiHeader.biYPelsPerMeter=11811;
	BmpInfo->bmiHeader.biClrUsed=0;
	BmpInfo->bmiHeader.biClrImportant=0;

	// convert the YUV pictuer(Y,Cb,Cr) into Gray picture(RGBbuf)
	HANDLE hloc1 = LocalAlloc(LMEM_ZEROINIT | LMEM_MOVEABLE,(sizeof(RGBQUAD) * 256));
	RGBQUAD *argbq = (RGBQUAD *) LocalLock(hloc1);
	for(int i=0; i<256; i++) {
		argbq[i].rgbBlue = argbq[i].rgbGreen = argbq[i].rgbRed = i;
		argbq[i].rgbReserved = 0;
	}
	memcpy(BmpInfo->bmiColors, argbq, sizeof(RGBQUAD) * 256);
	LocalUnlock(hloc1);
	LocalFree(hloc1);

    HANDLE hMem = GlobalAlloc(GHND, iWidth*iHeight);
	BYTE *lpBuf = (BYTE *)GlobalLock(hMem);
	
	//Make the inverse image up-side-down
	int nNum1,nNum2;
	for(i=0; i<iHeight; i++) {
		nNum1 = (iHeight-i-1)*iWidth;
		nNum2 = i*iWidth;
		memcpy(lpBuf+nNum1, Y+nNum2, iWidth);
	}

	// draw the picture
	GetClientRectSize();
	pDC->SetStretchBltMode(STRETCH_DELETESCANS);
	StretchDIBits(pDC->m_hDC,
					edge_x, edge_y, rw-2*edge_x, rh-2*edge_y,
					x_left, iHeight-y_bottom, x_right-x_left, y_bottom-y_top,
					lpBuf, BmpInfo, DIB_RGB_COLORS, SRCCOPY);

	GlobalUnlock(hMem);
	GlobalFree(hMem);

	ShowGrids(pDC); ShowSigns(pDC); ShowMVs(pDC);
}

// display the light gray image
void CYUVPlayback::ShowLGImage(CDC *pDC)
{
	DrawBackground(pDC);
	if (iCurrFrameNumber < 0)
		return;

	int BPP = 8;
	BmpInfo->bmiHeader.biSize=sizeof (BITMAPINFOHEADER);
	BmpInfo->bmiHeader.biWidth=iWidth;
	BmpInfo->bmiHeader.biHeight=iHeight;			// negative means up-to-bottom 
	BmpInfo->bmiHeader.biPlanes=1;
	BmpInfo->bmiHeader.biBitCount=(BPP<8?8:BPP);	// Our raster is byte-aligned
	BmpInfo->bmiHeader.biCompression=BI_RGB;
	BmpInfo->bmiHeader.biSizeImage=0;
	BmpInfo->bmiHeader.biXPelsPerMeter=11811;
	BmpInfo->bmiHeader.biYPelsPerMeter=11811;
	BmpInfo->bmiHeader.biClrUsed=0;
	BmpInfo->bmiHeader.biClrImportant=0;

	// convert the YUV pictuer(Y,Cb,Cr) into Gray picture(RGBbuf)
	HANDLE hloc1 = LocalAlloc(LMEM_ZEROINIT | LMEM_MOVEABLE,(sizeof(RGBQUAD) * 256));
	RGBQUAD *argbq = (RGBQUAD *) LocalLock(hloc1);
	for(int i=0; i<256; i++) {
		argbq[i].rgbBlue = argbq[i].rgbGreen = argbq[i].rgbRed = i;
		argbq[i].rgbReserved = 0;
	}
	memcpy(BmpInfo->bmiColors, argbq, sizeof(RGBQUAD) * 256);
	LocalUnlock(hloc1);
	LocalFree(hloc1);

    HANDLE hMem = GlobalAlloc(GHND, iWidth*iHeight);
	BYTE *lpBuf = (BYTE *)GlobalLock(hMem);
	
	//Make the inverse image up-side-down
	BYTE *p = lpBuf;
	unsigned char *y;
	for(i=0; i<iHeight; i++) {
		y = Y + ((iHeight-i-1)*iWidth);
		for (int j=0; j<iWidth; j++) {
			*p = 255 - (255-(unsigned char)(*y)) / 3;
			p++; y++;
		}
	}

	// draw the picture
	pDC->SetStretchBltMode(STRETCH_DELETESCANS);
	StretchDIBits(pDC->m_hDC,
					edge_x, edge_y, rw-2*edge_x, rh-2*edge_y,
					x_left, iHeight-y_bottom, x_right-x_left, y_bottom-y_top,
					lpBuf, BmpInfo, DIB_RGB_COLORS, SRCCOPY);

	GlobalUnlock(hMem);
	GlobalFree(hMem);

	ShowGrids(pDC); ShowSigns(pDC); ShowMVs(pDC);
}

// do not display image
void CYUVPlayback::ShowNDImage(CDC *pDC)
{
	DrawBackground(pDC);
	ShowGrids(pDC); ShowSigns(pDC); ShowMVs(pDC);
}

// show the macroblock grid
// sub macroblock grid will not be display
void CYUVPlayback::ShowGrids(CDC *pDC)
{
	if (!bShowGrid) return;

	CPen bluePen(PS_SOLID, 1, RGB(0,0, 255) );
	pDC->SelectObject(&bluePen);

	for (int by=0; by<iHeight/MB_SIZE; by++) {
		for (int bx=0; bx<iWidth/MB_SIZE; bx++) {
/*			if ( ( (bx*MB_SIZE>=x_left && bx*MB_SIZE<=x_right) ||
				   (bx*MB_SIZE+MB_SIZE-1>=x_left && bx*MB_SIZE+MB_SIZE-1<=x_right) ) &&
				 ( (by*MB_SIZE>=y_top && by*MB_SIZE<=y_bottom) ||
				   (by*MB_SIZE+MB_SIZE-1>=y_top && by*MB_SIZE+MB_SIZE-1<=y_bottom) ) ) {*/
			if ( bx*MB_SIZE>x_right || bx*MB_SIZE+MB_SIZE-1<x_left ||
				 by*MB_SIZE>y_bottom || by*MB_SIZE+MB_SIZE-1<y_top) {
				continue;
			}
			int x1 = toWindowX(bx*MB_SIZE);
			int x2 = toWindowX((bx+1)*MB_SIZE);
			int y1 = toWindowY(by*MB_SIZE);
			int y2 = toWindowY((by+1)*MB_SIZE);
			DrawRectangle(pDC, x1, y1, x2, y2);
		}
	}
}

// draw a rectangle
void CYUVPlayback::DrawRectangle(CDC *pDC, int x1, int y1, int x2, int y2)
{
	pDC->MoveTo(x1, y1);
	pDC->LineTo(x2, y1);
	pDC->LineTo(x2, y2);
	pDC->LineTo(x1, y2);
	pDC->LineTo(x1, y1);
}

// show the motion vectors of current picture
void CYUVPlayback::ShowMVs(CDC *pDC)
{
	if (!bShowMV) return;
	GetClientRectSize();

	for (int by=0; by<iHeight/MB_SIZE; by++) {
		for (int bx=0; bx<iWidth/MB_SIZE; bx++) {
			MBData* mbd = QMB + by*iWidth/MB_SIZE + bx;
			switch(mbd->mode) {
			case B16x16:
				DrawMV(pDC, bx*MB_SIZE+8, by*MB_SIZE+8, mbd->mv.mvx, mbd->mv.mvy);
				break;
			case B16x8:
				DrawMV(pDC, bx*MB_SIZE+8, by*MB_SIZE+4, mbd->mv_top.mvx, mbd->mv_top.mvy);
				DrawMV(pDC, bx*MB_SIZE+8, by*MB_SIZE+12, mbd->mv_bottom.mvx, mbd->mv_bottom.mvy);
				break;
			case B8x16:
				DrawMV(pDC, bx*MB_SIZE+4, by*MB_SIZE+8, mbd->mv_left.mvx, mbd->mv_left.mvy);
				DrawMV(pDC, bx*MB_SIZE+12, by*MB_SIZE+8, mbd->mv_right.mvx, mbd->mv_right.mvy);
				break;
			case B8x8:
				int i;
				for (i=0; i<4; i++) {
					switch(mbd->mvs[i].mode) {
					case B8:
						DrawMV(pDC, bx*MB_SIZE+8*(i%2)+4, by*MB_SIZE+8*(i/2)+4, mbd->mvs[i].mv.mvx, mbd->mvs[i].mv.mvy);
						break;
					case B8x4:
						DrawMV(pDC, bx*MB_SIZE+8*(i%2)+4, by*MB_SIZE+8*(i/2)+2, mbd->mvs[i].mv_top.mvx, mbd->mvs[i].mv_top.mvy);
						DrawMV(pDC, bx*MB_SIZE+8*(i%2)+4, by*MB_SIZE+8*(i/2)+6, mbd->mvs[i].mv_bottom.mvx, mbd->mvs[i].mv_bottom.mvy);
						break;
					case B4x8:
						DrawMV(pDC, bx*MB_SIZE+8*(i%2)+2, by*MB_SIZE+8*(i/2)+4, mbd->mvs[i].mv_left.mvx, mbd->mvs[i].mv_left.mvy);
						DrawMV(pDC, bx*MB_SIZE+8*(i%2)+6, by*MB_SIZE+8*(i/2)+4, mbd->mvs[i].mv_right.mvx, mbd->mvs[i].mv_right.mvy);
						break;
					case B4x4:
						DrawMV(pDC, bx*MB_SIZE+8*(i%2)+2, by*MB_SIZE+8*(i/2)+2, mbd->mvs[i].mvs[0].mvx, mbd->mvs[i].mvs[0].mvy);
						DrawMV(pDC, bx*MB_SIZE+8*(i%2)+6, by*MB_SIZE+8*(i/2)+2, mbd->mvs[i].mvs[1].mvx, mbd->mvs[i].mvs[1].mvy);
						DrawMV(pDC, bx*MB_SIZE+8*(i%2)+2, by*MB_SIZE+8*(i/2)+6, mbd->mvs[i].mvs[2].mvx, mbd->mvs[i].mvs[2].mvy);
						DrawMV(pDC, bx*MB_SIZE+8*(i%2)+6, by*MB_SIZE+8*(i/2)+6, mbd->mvs[i].mvs[3].mvx, mbd->mvs[i].mvs[3].mvy);
						break;
					default:
						break;
					}
				}
				break;
			default:
				break;
			}
		}
	}
}

// draw motion vector
void CYUVPlayback::DrawMV(CDC *pDC, int cx, int cy, int vx, int vy)
{
	if (cx<x_left || cx>x_right || cy<y_top || cy>y_bottom)
		return;
	int x1 = toWindowX(cx);
	int y1 = toWindowY(cy);
	int x2 = toWindowX(cx+(double)(vx)/4);
	int y2 = toWindowY(cy+(double)(vy)/4);

	CPen bluePen(PS_SOLID, 1, RGB(0,0, 255) );
	pDC->SelectObject(&bluePen);
	pDC->MoveTo(x2, y2);
	pDC->LineTo(x1, y1);

	CPen redPen(PS_SOLID, 1, RGB(255,0, 0) );
	pDC->SelectObject(&redPen);
	pDC->Rectangle(x1-1, y1-1, x1+1, y1+1);
}

// show the questionable blocks in red, and 
// show the modified blocks in green.
void CYUVPlayback::ShowSigns(CDC *pDC)
{
	if (!bShowSign) return;

	for (int by=0; by<iHeight/MB_SIZE; by++) {
		for (int bx=0; bx<iWidth/MB_SIZE; bx++) {
			if ( bx*MB_SIZE>x_right || bx*MB_SIZE+MB_SIZE-1<x_left ||
				 by*MB_SIZE>y_bottom || by*MB_SIZE+MB_SIZE-1<y_top) {
				continue;
			}
			MBData* mbd = QMB + by*iWidth/MB_SIZE + bx;
			int sign = CheckMBSign(mbd);
			DrawBlockSign(pDC, bx*MB_SIZE, by*MB_SIZE, 
						(bx+1)*MB_SIZE, (by+1)*MB_SIZE, sign);
		}
	}
}

// check if the macroblock sign
// return 0(NRM): normal block, no questionable MV, no modified MV
// return 1(QUE): at least has one questionable MV.
// return 2(MDF): at least has one modified MV, no questionable MV.
int CYUVPlayback::CheckMBSign(MBData *mbd)
{
	int modified = NRM;

	switch(mbd->mode) {
	case B16x16:
		if (mbd->mv.mark == QUE) return QUE;
		if (mbd->mv.mark == MDF) modified = MDF;
		break;
	case B16x8:
		if (mbd->mv_top.mark == QUE || mbd->mv_bottom.mark == QUE)
			return QUE;
		if (mbd->mv_top.mark == MDF || mbd->mv_bottom.mark == MDF)
			modified = MDF;
		break;
	case B8x16:
		if (mbd->mv_left.mark == QUE || mbd->mv_right.mark == QUE)
			return QUE;
		if (mbd->mv_left.mark == MDF || mbd->mv_right.mark == MDF)
			modified = MDF;
		break;
	case B8x8:
		for (int i=0; i<4; i++) {
			switch (mbd->mvs[i].mode) {
			case B8:
				if (mbd->mvs[i].mv.mark == QUE || mbd->mvs[i].mv.mark == QUE)
					return QUE;
				if (mbd->mvs[i].mv.mark == MDF || mbd->mvs[i].mv.mark == MDF)
					modified = MDF;
				break;
			case B8x4:
				if (mbd->mvs[i].mv_top.mark == QUE || mbd->mvs[i].mv_bottom.mark == QUE)
					return QUE;
				if (mbd->mvs[i].mv_top.mark == MDF || mbd->mvs[i].mv_bottom.mark == MDF)
					modified = MDF;
				break;
			case B4x8:
				if (mbd->mvs[i].mv_left.mark == QUE || mbd->mvs[i].mv_right.mark == QUE)
					return QUE;
				if (mbd->mvs[i].mv_left.mark == MDF || mbd->mvs[i].mv_right.mark == MDF)
					modified = MDF;
				break;
			case B4x4:
				for (int j=0; j<4; j++) {
					if (mbd->mvs[i].mvs[j].mark == QUE)
						return QUE;
					if (mbd->mvs[i].mvs[j].mark == MDF)
						modified = MDF;
				}
				break;
			}
		}
		break;
	}

	return modified;
}

// draw the block sign of questionable macroblock
// red -- questionable
// green -- modified
void CYUVPlayback::DrawBlockSign(CDC *pDC, int xl, int yt, int xr, int yb, int Q)
{
	int x1, x2, y1, y2;

	x1 = toWindowX(xl); x2 = toWindowX(xr);
	y1 = toWindowY(yt); y2 = toWindowY(yb);
	if (Q == QUE) { // questionable
		CPen redPen(PS_SOLID, 1, RGB(255,0,0) );
		pDC->SelectObject(&redPen);
		DrawRectangle(pDC, x1+1, y1+1, x2-1, y2-1);
	}
	if (Q == MDF) { // modified
		CPen greenPen(PS_SOLID, 1, RGB(0,255,0) );
		pDC->SelectObject(&greenPen);
		DrawRectangle(pDC, x1+1, y1+1, x2-1, y2-1);
	}
}

// translate the x pos of the YUV file into the pos of window
int CYUVPlayback::toWindowX(double x)
{
	int xx;
	GetClientRectSize();

	xx = (int)( (rw-2*edge_x) * (x-x_left) / (x_right-x_left) ) + edge_x;
	return xx;
}

// translate the y pos of the YUV file into the pos of window
int CYUVPlayback::toWindowY(double y)
{
	int yy;
	GetClientRectSize();

	yy = (int)( (rh-2*edge_y) * (y-y_top) / (y_bottom-y_top) ) + edge_y;
	return yy;
}

// translate the x pos of the window into the pos of YUV file
double CYUVPlayback::toPictureX(int x)
{
	double xx;
	GetClientRectSize();

	xx = (double)(( (x_right-x_left) * (x-edge_x) / (rw-2*edge_x) ) + x_left);
	return xx;
}

// translate the y pos of the window into the pos of YUV file
double CYUVPlayback::toPictureY(int y)
{
	double yy;
	GetClientRectSize();

	yy = (double)(( (y_bottom-y_top) * (y-edge_y) / (rh-2*edge_y) ) + y_top);
	return yy;
}

// recalculate the 4 corner positions of YUV picture, and the x, y edges
// when zoom in/out and move by drag the picture.
void CYUVPlayback::ReCalulateShowParam()
{
	GetClientRectSize();

	// calculate the draw area ( 4 corner positions )
	x_left = (int)(CenterX - iWidth / ZoomFactor / 2);
	x_right = (int)(CenterX + iWidth / ZoomFactor / 2);
	if (x_left<0) x_left = 0; if (x_right>iWidth-1) x_right = iWidth-1;

	y_top = (int)(CenterY - iHeight / ZoomFactor / 2);
	y_bottom = (int)(CenterY + iHeight / ZoomFactor / 2);
	if (y_top<0) y_top = 0; if (y_bottom>iHeight-1) y_bottom = iHeight-1;

	// calculate the edge pro rate of 16 pixels in orignal YUV picture
	edge_x = (int)(16 * rw / (x_right-x_left+32)) + 1;
	edge_y = (int)(16 * rh / (y_bottom-y_top+32)) + 1;
}

// Get the window width & heidht
void CYUVPlayback::GetClientRectSize()
{
	CRect rect;
	GetClientRect(&rect);
	rw = rect.Width();
	rh = rect.Height();
}

// refresh the background of the window
void CYUVPlayback::DrawBackground(CDC *pDC)
{
	CRect rect;
	GetClientRect(&rect);
	rw = rect.Width();
	rh = rect.Height();

	HBRUSH hbkgbr;
	hbkgbr= (HBRUSH)GetStockObject(WHITE_BRUSH);
	FillRect(pDC->m_hDC, rect, hbkgbr);
	DeleteObject(hbkgbr);

	return;
}

// find all questionable MBs in the current picture.
// all the questionable MBs are stored in QMB[].
// multi-questionable MVs in the same MB is store as one element in QMB[]/
void CYUVPlayback::FindQuestionableMV()
{
	TotalQMB = 0;
	BOOL bFirst = TRUE;

	for (int by=0; by<iHeight/MB_SIZE; by++) {
		for (int bx=0; bx<iWidth/MB_SIZE; bx++) {
			CreateOneQMB(bx, by);
			MBData* mbd = QMB + by*iWidth/MB_SIZE + bx;
			if (CheckMBSign(mbd) == QUE) {
				TotalQMB ++;
				if (bFirst) {
					QMB_bx = bx; QMB_by = by;
					pDlg->m_FocusArea.SetFocusArea(mbd, bx, by);
					bFirst = FALSE;
				}
			}
		}
	}
}

// create a QMB for test, should be deleted finally.
void CYUVPlayback::CreateOneQMB(int bx, int by)
{
	MBData *mbd;
	mbd = QMB + by*iWidth/MB_SIZE + bx;

	mbd->bx = bx;
	mbd->by = by;
	switch(rand()%10) {
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
		mbd->mode = B16x16;
		mbd->mv.mvx = (int)(rand()%64 - 32);
		mbd->mv.mvy = (int)(rand()%64 - 32);
		MarkIt(&(mbd->mv));
		break;
	case 7:
		mbd->mode = B16x8;
		mbd->mv_top.mvx = (int)(rand()%64 - 32);
		mbd->mv_top.mvy = (int)(rand()%64 - 32);
		MarkIt(&(mbd->mv_top));
		mbd->mv_bottom.mvx = (int)(rand()%64 - 32);
		mbd->mv_bottom.mvy = (int)(rand()%64 - 32);
		MarkIt(&(mbd->mv_bottom));
		break;
	case 8:
		mbd->mode = B8x16;
		mbd->mv_left.mvx = (int)(rand()%64 - 32);
		mbd->mv_left.mvy = (int)(rand()%64 - 32);
		MarkIt(&(mbd->mv_left));
		mbd->mv_right.mvx = (int)(rand()%64 - 32);
		mbd->mv_right.mvy = (int)(rand()%64 - 32);
		MarkIt(&(mbd->mv_right));
		break;
	case 9:
		mbd->mode = B8x8;
		for (int i=0; i<4; i++) {
			switch(rand()%10) {
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
				mbd->mvs[i].mode = B8;
				mbd->mvs[i].mv.mvx = (int)(rand()%64 - 32);
				mbd->mvs[i].mv.mvy = (int)(rand()%64 - 32);
				MarkIt(&(mbd->mvs[i].mv));
				break;
			case 7:
				mbd->mvs[i].mode = B8x4;
				mbd->mvs[i].mv_top.mvx = (int)(rand()%64 - 32);
				mbd->mvs[i].mv_top.mvy = (int)(rand()%64 - 32);
				MarkIt(&(mbd->mvs[i].mv_top));
				mbd->mvs[i].mv_bottom.mvx = (int)(rand()%64 - 32);
				mbd->mvs[i].mv_bottom.mvy = (int)(rand()%64 - 32);
				MarkIt(&(mbd->mvs[i].mv_bottom));
				break;
			case 8:
				mbd->mvs[i].mode = B4x8;
				mbd->mvs[i].mv_left.mvx = (int)(rand()%64 - 32);
				mbd->mvs[i].mv_left.mvy = (int)(rand()%64 - 32);
				MarkIt(&(mbd->mvs[i].mv_left));
				mbd->mvs[i].mv_right.mvx = (int)(rand()%64 - 32);
				mbd->mvs[i].mv_right.mvy = (int)(rand()%64 - 32);
				MarkIt(&(mbd->mvs[i].mv_right));
				break;
			case 9:
				mbd->mvs[i].mode = B4x4;
				for (int j=0; j<4; j++) {
					mbd->mvs[i].mvs[j].mvx = (int)(rand()%64 - 32);
					mbd->mvs[i].mvs[j].mvy = (int)(rand()%64 - 32);
					MarkIt(&(mbd->mvs[i].mvs[j]));
				}
				break;
			}
		}
		break;
	}
}

// should be deleted finally.
void CYUVPlayback::MarkIt(MVData *mv)
{
	if (rand()%100 <= 5) {
		if (rand()%100 <= 80)
			mv->mark = QUE; // questionable
		else
			mv->mark = MDF; // modified
	} else {
		mv->mark = NRM; // normal
	}
}
