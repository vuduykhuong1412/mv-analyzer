// YUVAnalyzerDlg.h : header file
//

#if !defined(AFX_YUVANALYZERDLG_H__5CF3D687_DE3A_40E2_B4BB_92356F153B0D__INCLUDED_)
#define AFX_YUVANALYZERDLG_H__5CF3D687_DE3A_40E2_B4BB_92356F153B0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CDXCSIZINGDIALOG.H"
#include "MVplayback.h"
#include "MVreference.h"
#include "FocusArea.h"
#include "FocusRef.h"
#include "Convert.h"
#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CYUVAnalyzerDlg dialog

// YUV -- Colorful
// YY  -- Gray
// LG  -- LightGray
// ND  -- Not Display
enum { YUV, YY, LG, ND };

class CYUVAnalyzerDlg : public cdxCSizingDialog
{
// Construction
public:
	CYUVAnalyzerDlg(CWnd* pParent = NULL);	// standard constructor
	void OpenFileA();

// Dialog Data
	//{{AFX_DATA(CYUVAnalyzerDlg)
	enum { IDD = IDD_YUVANALYZER_DIALOG };
	CButton	m_sign;
	CButton	m_file_open;
	CButton	m_prev;
	CButton	m_next;
	CButton	m_playbackBBRight;
	CButton	m_playbackBBLeft;
	CButton	m_playbackBBDown;
	CButton	m_playbackBBUp;
	CStatic	m_psnr;
	CButton	m_grid;
	CButton	m_YUV;
	CFocusArea	m_FocusArea;
	CFocusRef	m_FocusRef;
	CButton	m_bMV;
	CYUVReference	m_Reference;
	CYUVPlayback	m_playback;
	CButton	m_setting;
	CButton	m_play_pause;
	CStatic	m_frame_num;
	CSliderCtrl	m_progress;
	//}}AFX_DATA

	int iWidth,iHeight;	// YUV file width & height setting by m_setting
	int fps;			// frame per second
	UINT playback_timer;// timer for fps
	BOOL bPlay;			// play or pause;
	int  bYUV;		// display Colorful YUV or Y only or U only or V only
	int iCurrFrameNumber;	// current frame number, start from 0, 1, 2, ......
	char sFileNameA[128];	// 
	char sFileNameB[128];	// 
	int iTotalFrameNumber;	//

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CYUVAnalyzerDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CYUVAnalyzerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	afx_msg void OnPlay();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnReleasedcaptureProgress(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSetting();
	afx_msg void OnMV();
	afx_msg void OnYUV();
	afx_msg void OnGrid();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnNext();
	afx_msg void OnPrev();
	afx_msg void OnPlaybackBbUp();
	afx_msg void OnPlaybackBbDown();
	afx_msg void OnPlaybackBbLeft();
	afx_msg void OnPlaybackBbRight();
	afx_msg void OnSign();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL IsDraging;
	CPoint DragPntStart;
	void ReStart(void);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_YUVANALYZERDLG_H__5CF3D687_DE3A_40E2_B4BB_92356F153B0D__INCLUDED_)
