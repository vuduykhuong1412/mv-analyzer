#if !defined(AFX_FOCUSAREA_H__C5815FC7_9857_444A_8123_AA176B78EA85__INCLUDED_)
#define AFX_FOCUSAREA_H__C5815FC7_9857_444A_8123_AA176B78EA85__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FocusArea.h : header file
//
#include "defines.h"

class CYUVAnalyzerDlg;

/////////////////////////////////////////////////////////////////////////////
// CFocusArea window
class CFocusArea : public CStatic
{
// Construction
public:
	CFocusArea();

// Attributes
public:

// Operations
public:
	CYUVAnalyzerDlg* pDlg;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFocusArea)
	//}}AFX_VIRTUAL

// Implementation
public:
	void NextMV(void);
	void SetFocusArea(MBData *mbd, int bx, int by);
	virtual ~CFocusArea();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFocusArea)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	int CurrMV_No;
	void DrawBlock(CDC *pDC, int x1, int y1, int x2, int y2, int Q);
	void DrawArrow(CDC *pDC, int vx, int vy, int cx, int cy, int Q);
	int toWindowX(double x);
	int toWindowY(double y);
	int toPictureX(int x);
	int toPictureY(int y);
	void ShowFocusBlock(CDC *pDC);
	void ShowFocusArea(CDC *pDC);
	CYUVPlayback *Pic;
	int FocusBlockY;
	int FocusBlockX;
	unsigned char Y[FOCUS_PIX_SIZE][FOCUS_PIX_SIZE];
	unsigned char * RGBbuf;
	MBData	*qmb;	// block structure
	BITMAPINFO * BmpInfo;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOCUSAREA_H__C5815FC7_9857_444A_8123_AA176B78EA85__INCLUDED_)
