// YUVAnalyzer.h : main header file for the YUVANALYZER application
//

#if !defined(AFX_YUVANALYZER_H__0CACBD6F_9644_4E0E_8513_89AC5774453B__INCLUDED_)
#define AFX_YUVANALYZER_H__0CACBD6F_9644_4E0E_8513_89AC5774453B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CYUVAnalyzerApp:
// See YUVAnalyzer.cpp for the implementation of this class
//

class CYUVAnalyzerApp : public CWinApp
{
public:
	CYUVAnalyzerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CYUVAnalyzerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CYUVAnalyzerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_YUVANALYZER_H__0CACBD6F_9644_4E0E_8513_89AC5774453B__INCLUDED_)
