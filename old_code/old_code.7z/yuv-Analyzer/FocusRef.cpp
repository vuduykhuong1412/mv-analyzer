// FocusRef.cpp : implementation file
//

#include "stdafx.h"
#include "yuvanalyzer.h"
#include "YUVReference.h"
#include "FocusRef.h"
#include "YUVAnalyzerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFocusRef

CFocusRef::CFocusRef()
{
	mv = NULL;
	wm = hm = -1;
	ox = oy = FOCUS_RANGE;
	BmpInfo=(BITMAPINFO*)new char [sizeof(BITMAPINFO)+sizeof(RGBQUAD)*256];
}

CFocusRef::~CFocusRef()
{
	delete BmpInfo;
}


BEGIN_MESSAGE_MAP(CFocusRef, CStatic)
	//{{AFX_MSG_MAP(CFocusRef)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFocusRef message handlers

void CFocusRef::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	ShowFocusArea(&dc);
}

void CFocusRef::ShowFocusArea(CDC *pDC)
{
	CRect rect;
	GetClientRect(&rect);
	HBRUSH hbkgbr;

	// refresh the backgroud
	hbkgbr= (HBRUSH)GetStockObject(WHITE_BRUSH);
	FillRect(pDC->m_hDC, rect, hbkgbr);
	DeleteObject(hbkgbr);

	int i;         
	HANDLE hMem;
	BYTE *lpBuf;

	int BPP = 8;

	BmpInfo->bmiHeader.biSize=sizeof (BITMAPINFOHEADER);
	BmpInfo->bmiHeader.biWidth=FOCUS_PIX_SIZE;
	BmpInfo->bmiHeader.biHeight=FOCUS_PIX_SIZE;			// negative means up-to-bottom 
	BmpInfo->bmiHeader.biPlanes=1;
	BmpInfo->bmiHeader.biBitCount=(BPP<8?8:BPP);	// Our raster is byte-aligned
	BmpInfo->bmiHeader.biCompression=BI_RGB;
	BmpInfo->bmiHeader.biSizeImage=0;
	BmpInfo->bmiHeader.biXPelsPerMeter=11811;
	BmpInfo->bmiHeader.biYPelsPerMeter=11811;
	BmpInfo->bmiHeader.biClrUsed=0;
	BmpInfo->bmiHeader.biClrImportant=0;

	HANDLE hloc1;
	RGBQUAD *argbq;
	hloc1 = LocalAlloc(LMEM_ZEROINIT | LMEM_MOVEABLE,(sizeof(RGBQUAD) * 256));
	argbq = (RGBQUAD *) LocalLock(hloc1);
	for(i=0;i<256;i++) {
		argbq[i].rgbBlue=i;
		argbq[i].rgbGreen=i;
		argbq[i].rgbRed=i;
		argbq[i].rgbReserved=0;
	}
	memcpy(BmpInfo->bmiColors, argbq, sizeof(RGBQUAD) * 256);
	LocalUnlock(hloc1);
	LocalFree(hloc1);

    hMem=GlobalAlloc(GHND, FOCUS_PIX_SIZE*FOCUS_PIX_SIZE);
	lpBuf=(BYTE *)GlobalLock(hMem);
	
	if (mv==NULL || wm<0 || hm<0)
		return;
	int y, x;
	for (y=0; y<FOCUS_PIX_SIZE; y++)
		for (x=0; x<FOCUS_PIX_SIZE; x++)
			tempY[y][x] = 255 - (255-Y[y][x]) / 2;
 	for (y=oy*FOCUS_ZOOM+mv->mvy*2;
		y<oy*FOCUS_ZOOM+mv->mvy*2+hm*FOCUS_ZOOM; y++)
		for (x=ox*FOCUS_ZOOM+mv->mvx*2;
			x<ox*FOCUS_ZOOM+mv->mvx*2+wm*FOCUS_ZOOM; x++)
			tempY[y][x] = Y[y][x];

    //�����õ�ͼ����� 
	//Make the inverse image normal
	for(i=0;i<FOCUS_PIX_SIZE;i++) {
		memcpy(lpBuf+FOCUS_PIX_SIZE*(FOCUS_PIX_SIZE-1-i), tempY[i], FOCUS_PIX_SIZE);
	}

	pDC->SetStretchBltMode(STRETCH_DELETESCANS);
	StretchDIBits(pDC->m_hDC,0,0,rect.Width(),rect.Height(),0,0,FOCUS_PIX_SIZE,FOCUS_PIX_SIZE,
				  lpBuf, BmpInfo, DIB_RGB_COLORS, SRCCOPY);  

	GlobalUnlock(hMem);
	GlobalFree(hMem);
}

void CFocusRef::SetSearchArea(CYUVReference *p, MVData* mvd, int bx, int by, int sx, int sy, int w, int h)
{
	int x, y, i, j, yy, xx;
	unsigned char val;

	mv = mvd; wm = w; hm = h; ox = FOCUS_RANGE+sx; oy = FOCUS_RANGE+sy;
	FocusBlockX = bx;
	FocusBlockY = by;
	Pic = p;

	for (y=by*MB_SIZE-FOCUS_RANGE; y<by*MB_SIZE+MB_SIZE+FOCUS_RANGE; y++) {
		for (x=bx*MB_SIZE-FOCUS_RANGE; x<bx*MB_SIZE+MB_SIZE+FOCUS_RANGE; x++) {
			if (y<0 || x <0 || y >= p->iHeight || x >= p->iWidth) {
				val = FOCUS_BKG_Y;
			} else {
				val = *(p->Y + y*p->iWidth + x);
			}
			yy = (y - (by*MB_SIZE-FOCUS_RANGE)) * FOCUS_ZOOM;
			xx = (x - (bx*MB_SIZE-FOCUS_RANGE)) * FOCUS_ZOOM;
			for (j=yy; j<yy+FOCUS_ZOOM; j++) {
				for (i=xx; i<xx+FOCUS_ZOOM; i++) {
					Y[j][i] = val;
				}
			}
		}
	}

	Invalidate(FALSE);
}

void CFocusRef::ShowFocusBlock(CDC *pDC)
{
	HBRUSH hBrush = CreateSolidBrush( RGB(255,255,255) );
	CPen redPen(PS_SOLID, 1, RGB(255,0, 0) );
	pDC->SelectObject(&redPen);

	int x1 = FOCUS_RANGE * FOCUS_ZOOM - 1;
	int x2 = (FOCUS_RANGE + MB_SIZE) * FOCUS_ZOOM;
	int y1 = FOCUS_RANGE * FOCUS_ZOOM - 1;
	int y2 = (FOCUS_RANGE + MB_SIZE) * FOCUS_ZOOM;
	pDC->MoveTo( toWindowX(x1),		toWindowY(y1) );
	pDC->LineTo( toWindowX(x2),	toWindowY(y1)) ;
	pDC->LineTo( toWindowX(x2),	toWindowY(y2) );
	pDC->LineTo( toWindowX(x1),		toWindowY(y2) );
	pDC->LineTo( toWindowX(x1),		toWindowY(y1) );
}

// translate the x pos of the YUV file into the pos of window
int CFocusRef::toWindowX(int x)
{
	int xx;
	CRect rect;
	GetClientRect(&rect);

	xx = ( rect.Width() * x / FOCUS_PIX_SIZE );
	return xx;
}

// translate the y pos of the YUV file into the pos of window
int CFocusRef::toWindowY(int y)
{
	int yy;
	CRect rect;
	GetClientRect(&rect);

	yy = ( rect.Height() * y / FOCUS_PIX_SIZE );
	return yy;
}

// translate the x pos of the window into the pos of YUV file
int CFocusRef::toPictureX(int x)
{
	return 0;
}

// translate the y pos of the window into the pos of YUV file
int CFocusRef::toPictureY(int y)
{
	return 0;
}

void CFocusRef::MoveUp(void)
{
	if ((mv->mvy-1)-oy*FOCUS_ZOOM/2 > -FOCUS_PIX_SIZE/2)
		mv->mvy -= 1;
	Invalidate(FALSE);
	pDlg->m_FocusArea.Invalidate(FALSE);
}

void CFocusRef::MoveDown(void)
{
	if ((mv->mvy+1)+oy*FOCUS_ZOOM/2 < FOCUS_PIX_SIZE/2)
		mv->mvy += 1;
	Invalidate(FALSE);
	pDlg->m_FocusArea.Invalidate(FALSE);
}

void CFocusRef::MoveLeft(void)
{
	if ((mv->mvx-1) - ox*FOCUS_ZOOM/2 > -FOCUS_PIX_SIZE/2)
		mv->mvx -= 1;
	Invalidate(FALSE);
	pDlg->m_FocusArea.Invalidate(FALSE);
}

void CFocusRef::MoveRight(void)
{
	if ((mv->mvx+1)+ox*FOCUS_ZOOM/2 < FOCUS_PIX_SIZE/2)
		mv->mvx += 1;
	Invalidate(FALSE);
	pDlg->m_FocusArea.Invalidate(FALSE);
}

void CFocusRef::RefMoveUp(void)
{
	if (FocusBlockY-1 >= 0) {
		SetSearchArea(Pic, mv, FocusBlockX, FocusBlockY-1, ox, oy, wm, hm);
		Invalidate(FALSE);
	}
}

void CFocusRef::RefMoveDown(void)
{
	if (FocusBlockY+1 <= Pic->iHeight/MB_SIZE-1) {
		SetSearchArea(Pic, mv, FocusBlockX, FocusBlockY+1, ox, oy, wm, hm);
		Invalidate(FALSE);
	}
}

void CFocusRef::RefMoveLeft(void)
{
	if (FocusBlockX-1 >= 0) {
		SetSearchArea(Pic, mv, FocusBlockX-1, FocusBlockY, ox, oy, wm, hm);
		Invalidate(FALSE);
	}
}

void CFocusRef::RefMoveRight(void)
{
	if (FocusBlockX+1 <= Pic->iWidth/MB_SIZE-1) {
		SetSearchArea(Pic, mv, FocusBlockX+1, FocusBlockY, ox, oy, wm, hm);
		Invalidate(FALSE);
	}
}
