//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by YUVAnalyzer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_YUVANALYZER_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDD_SETTING                     130
#define IDC_PLAYBACK_A                  1004
#define IDC_PLAYBACK_AA                 1005
#define IDC_PLAY                        1006
#define IDC_FILE_B_OPEN                 1007
#define IDC_PLAYBACK_BB                 1007
#define IDC_PROGRESS                    1008
#define IDC_FILE_A_OPEN                 1009
#define IDC_PREV                        1010
#define IDC_NEXT                        1011
#define IDC_FRAME_NUM                   1012
#define IDC_PSNR                        1013
#define IDC_SETTING                     1015
#define IDC_SINGLE_DUAL                 1016
#define IDC_PLAYBACK_B                  1017
#define IDC_SIZE_LIST                   1022
#define IDC_SIZE_WIDTH                  1023
#define IDC_SIZE_HEIGHT                 1024
#define IDC_FPS_LIST                    1026
#define IDC_MV                          1028
#define IDC_ORIG_SIZE                   1029
#define IDC_YUV                         1030
#define IDC_Y_ONLY                      1031
#define IDC_PLAYBACK_BB_UP              1031
#define IDC_PLAYBACK_BB_DOWN            1032
#define IDC_PLAYBACK_BB_RIGHT           1033
#define IDC_GRID                        1034
#define IDC_PLAYBACK_BB_LEFT            1035
#define IDC_FILE_OPEN                   1036
#define IDC_SIGN                        1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
